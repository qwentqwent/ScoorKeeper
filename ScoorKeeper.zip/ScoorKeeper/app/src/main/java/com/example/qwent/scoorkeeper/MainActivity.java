package com.example.qwent.scoorkeeper;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int scoreTeamA = 0;
    int errorTeamA = 0;
    int scoreTeamB = 0;
    int errorTeamB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Increase the score for Team A by 1 point.
     */
    public void freeThrowA (View view){
        scoreTeamA = scoreTeamA + 1;
        displayFroTeamA( scoreTeamA );
    }

    /**
     * Increase the score for Team A by 4 point.
     */
    public void points4A (View view){
        scoreTeamA = scoreTeamA + 4;
        displayFroTeamA( scoreTeamA );
    }

    /**
     *Increase the error for Team A by 1 point.
     */
    public void errorTeamAScor (View view){
        errorTeamA = errorTeamA + 1;
        displayErrorTeamA( errorTeamA );
    }

    /**
     * Increase the score for Team B by 1 point.
     */
    public void freeThrowB (View view){
        scoreTeamB = scoreTeamB + 1;
        displayFroTeamB( scoreTeamB );
    }

    /**
     * Increase the score for Team B by 4 point.
     */
    public void points4B (View view){
        scoreTeamB = scoreTeamB + 4;
        displayFroTeamB( scoreTeamB );
    }

    /**
     *Increase the error for Team B by 1 point.
     */
    public void errorTeamBScor (View view){
        errorTeamB = errorTeamB + 1;
        displayErrorTeamB( errorTeamB );
    }

    /**
     * Reset.
     */
    public void reset (View view){
        displayFroTeamA( scoreTeamA = 0 );
        displayFroTeamB( scoreTeamB = 0 );
        displayErrorTeamA(errorTeamA = 0);
        displayErrorTeamB(errorTeamB = 0);
    }

    /**
     * Display the given score Team A.
     */
    public void displayFroTeamA (int score){
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * Display the given score Team B.
     */
    public void displayFroTeamB (int score){
        TextView scoreView = (TextView) findViewById(R.id.team_b_score);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * Display the given Error Team B.
     */
    public void displayErrorTeamA (int score){
        TextView scoreView = (TextView) findViewById(R.id.team_a_error);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * Display the given Error Team B.
     */
    public void displayErrorTeamB (int score){
        TextView scoreView = (TextView) findViewById(R.id.team_b_error);
        scoreView.setText(String.valueOf(score));
    }
}
